const els = {
  input: document.getElementById("stats-user-name"),
  loadBtn: document.getElementById("load-user-stats-btn"),

  totalSessions: document.getElementById("total-sessions"),
  avgWpm: document.getElementById("avg-wpm"),
  avgAccuracy: document.getElementById("avg-accuracy"),

  topCharacters: document.getElementById("top-characters"),
  topWords: document.getElementById("top-words"),
  topBigrams: document.getElementById("top-bigrams"),
};

function renderList(container, data) {
  container.innerHTML = "";

  if (!data || !data.length) {
    container.innerHTML = "<li>Aucune donnée</li>";
    return;
  }

  data.forEach(([key, value]) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${key}</span><strong>${value}</strong>`;
    container.appendChild(li);
  });
}

async function loadStats() {
  const user = els.input.value.trim();

  if (!user) {
    alert("Entre un nom");
    return;
  }

  try {
    const data = await fetchJson(`${API_BASE_URL}/stats/user/${user}`);

    els.totalSessions.textContent = data.total_sessions;
    els.avgWpm.textContent = formatNumber(data.average_wpm);
    els.avgAccuracy.textContent = formatNumber(data.average_accuracy) + "%";

    renderList(els.topCharacters, data.top_characters);
    renderList(els.topWords, data.top_words);
    renderList(els.topBigrams, data.top_bigrams);

  } catch (err) {
    console.error(err);
    alert("Erreur chargement stats");
  }
}

els.loadBtn.addEventListener("click", loadStats);